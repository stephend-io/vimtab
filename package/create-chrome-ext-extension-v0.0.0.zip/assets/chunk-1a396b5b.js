import"./chunk-b3cdbad1.js";const e=async()=>{const t=await chrome.tabs.getCurrent();console.log(t),chrome.tabs.create({url:"../../newtabActual.html"}),chrome.tabs.remove(t==null?void 0:t.id)};e();
