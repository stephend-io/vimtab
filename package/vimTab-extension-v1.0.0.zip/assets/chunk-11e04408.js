import"./chunk-b3cdbad1.js";const e=async()=>{const t=await chrome.tabs.getCurrent();chrome.tabs.create({url:"../../newtabActual.html",active:!0}),chrome.tabs.remove(t==null?void 0:t.id)};e();
